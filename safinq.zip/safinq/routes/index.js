var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  console.log(req.query)
  var context = {};
  context.query = req.query;
  res.render('get', context);
});

router.post('/', function(req, res, next) {
  console.log(req.body)
  var context = {};
  context.query = req.query;
  context.body = req.body;
  res.render('post',context);
});

module.exports = router;
