## To run the app
```
yarn install
or 
npm install

yarn start
or
npm start
```

live at localhost:3000
